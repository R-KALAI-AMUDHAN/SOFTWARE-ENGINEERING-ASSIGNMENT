from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine
from app import models  # noqa: F401  (ensures models are registered before create_all)
from app.routers import users, sensors, risk, alerts, shelters, reports, dashboard

app = FastAPI(
    title="Intelligent Disaster Early Warning and Evacuation Management System",
    description=(
        "API for real-time sensor ingestion, AI/ML disaster-risk prediction, "
        "multi-channel alerts, GIS-based shelter/evacuation data, citizen "
        "incident reporting, and an authority dashboard."
    ),
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)


@app.get("/", tags=["Health"])
def health_check():
    return {"status": "ok", "service": "disaster-early-warning-system"}


app.include_router(users.router)
app.include_router(sensors.router)
app.include_router(risk.router)
app.include_router(alerts.router)
app.include_router(shelters.router)
app.include_router(reports.router)
app.include_router(dashboard.router)
