from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr


# ---------- Auth / Users ----------
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str = "citizen"
    phone: Optional[str] = None


class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: str
    phone: Optional[str] = None

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


# ---------- Sensors ----------
class SensorCreate(BaseModel):
    name: str
    sensor_type: str
    latitude: float
    longitude: float
    region: Optional[str] = None


class SensorOut(SensorCreate):
    id: int
    is_active: bool

    class Config:
        from_attributes = True


class ReadingCreate(BaseModel):
    metric: str
    value: float


class ReadingOut(ReadingCreate):
    id: int
    sensor_id: int
    recorded_at: datetime

    class Config:
        from_attributes = True


# ---------- Risk ----------
class RiskOut(BaseModel):
    id: int
    sensor_id: int
    disaster_type: str
    risk_level: str
    risk_score: float
    latitude: float
    longitude: float
    region: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Alerts ----------
class AlertCreate(BaseModel):
    title: str
    message: str
    disaster_type: str
    risk_level: str
    region: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    radius_km: float = 10.0
    channels: str = "app,sms,email"


class AlertOut(AlertCreate):
    id: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Shelters ----------
class ShelterCreate(BaseModel):
    name: str
    latitude: float
    longitude: float
    capacity: int = 0
    current_occupancy: int = 0
    food_supplies: str = "adequate"
    medical_supplies: str = "adequate"
    status: str = "open"
    contact_phone: Optional[str] = None


class ShelterUpdate(BaseModel):
    current_occupancy: Optional[int] = None
    food_supplies: Optional[str] = None
    medical_supplies: Optional[str] = None
    status: Optional[str] = None


class ShelterOut(ShelterCreate):
    id: int
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------- Incident Reports ----------
class ReportCreate(BaseModel):
    category: str
    description: Optional[str] = None
    latitude: float
    longitude: float


class ReportOut(ReportCreate):
    id: int
    status: str
    reporter_id: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ReportStatusUpdate(BaseModel):
    status: str
