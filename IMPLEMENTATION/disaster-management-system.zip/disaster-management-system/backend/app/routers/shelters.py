from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/shelters", tags=["Shelters"])


@router.post("/", response_model=schemas.ShelterOut, status_code=201)
def create_shelter(
    payload: schemas.ShelterCreate,
    db: Session = Depends(get_db),
    _=Depends(auth.require_roles("authority", "admin")),
):
    shelter = models.Shelter(**payload.model_dump())
    db.add(shelter)
    db.commit()
    db.refresh(shelter)
    return shelter


@router.get("/", response_model=List[schemas.ShelterOut])
def list_shelters(db: Session = Depends(get_db)):
    return db.query(models.Shelter).all()


@router.patch("/{shelter_id}", response_model=schemas.ShelterOut)
def update_shelter(
    shelter_id: int,
    payload: schemas.ShelterUpdate,
    db: Session = Depends(get_db),
    _=Depends(auth.require_roles("authority", "responder", "admin")),
):
    shelter = db.query(models.Shelter).filter(models.Shelter.id == shelter_id).first()
    if not shelter:
        raise HTTPException(status_code=404, detail="Shelter not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(shelter, field, value)

    db.commit()
    db.refresh(shelter)
    return shelter
