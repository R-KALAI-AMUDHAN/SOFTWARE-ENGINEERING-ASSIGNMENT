from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/reports", tags=["Citizen Incident Reports"])


@router.post("/", response_model=schemas.ReportOut, status_code=201)
def create_report(payload: schemas.ReportCreate, db: Session = Depends(get_db)):
    # Citizen reporting is kept open/anonymous by default (no auth
    # required) so people can report blocked roads / people needing
    # help even without creating an account during an emergency.
    report = models.IncidentReport(**payload.model_dump())
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


@router.get("/", response_model=List[schemas.ReportOut])
def list_reports(status_filter: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(models.IncidentReport)
    if status_filter:
        q = q.filter(models.IncidentReport.status == status_filter)
    return q.order_by(models.IncidentReport.created_at.desc()).all()


@router.patch("/{report_id}/status", response_model=schemas.ReportOut)
def update_report_status(
    report_id: int,
    payload: schemas.ReportStatusUpdate,
    db: Session = Depends(get_db),
    _=Depends(auth.require_roles("responder", "authority", "admin")),
):
    report = db.query(models.IncidentReport).filter(models.IncidentReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    report.status = payload.status
    db.commit()
    db.refresh(report)
    return report
