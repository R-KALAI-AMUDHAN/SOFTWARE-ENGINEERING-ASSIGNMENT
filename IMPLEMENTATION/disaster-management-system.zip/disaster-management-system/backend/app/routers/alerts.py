from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/alerts", tags=["Alerts"])


@router.post("/", response_model=schemas.AlertOut, status_code=201)
def create_alert(
    payload: schemas.AlertCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.require_roles("authority", "admin")),
):
    """
    Authority/admin creates a location-specific alert. In a production
    system this would fan out to push notifications / SMS gateway (e.g.
    Twilio) / email service / web sockets. Here, we persist the alert
    and expose it via GET so the citizen app + dashboard can poll or
    subscribe to it -- the "channels" field records which channels it
    was (simulated to be) dispatched on.
    """
    alert = models.Alert(**payload.model_dump(), created_by=current_user.id)
    db.add(alert)
    db.commit()
    db.refresh(alert)
    return alert


@router.get("/", response_model=List[schemas.AlertOut])
def list_alerts(active_only: bool = True, db: Session = Depends(get_db)):
    q = db.query(models.Alert)
    if active_only:
        q = q.filter(models.Alert.is_active == True)  # noqa: E712
    return q.order_by(models.Alert.created_at.desc()).all()


@router.put("/{alert_id}/deactivate", response_model=schemas.AlertOut)
def deactivate_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    _=Depends(auth.require_roles("authority", "admin")),
):
    alert = db.query(models.Alert).filter(models.Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.is_active = False
    db.commit()
    db.refresh(alert)
    return alert
