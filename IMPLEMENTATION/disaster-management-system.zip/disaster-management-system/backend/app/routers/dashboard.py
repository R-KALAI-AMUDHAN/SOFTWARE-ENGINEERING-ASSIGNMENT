from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app import models

router = APIRouter(prefix="/dashboard", tags=["Authority Dashboard"])


@router.get("/summary")
def summary(db: Session = Depends(get_db)):
    total_sensors = db.query(models.Sensor).count()
    active_alerts = db.query(models.Alert).filter(models.Alert.is_active == True).count()  # noqa: E712
    total_shelters = db.query(models.Shelter).count()
    open_reports = (
        db.query(models.IncidentReport)
        .filter(models.IncidentReport.status != models.ReportStatus.resolved)
        .count()
    )
    total_capacity = sum(s.capacity for s in db.query(models.Shelter).all())
    total_occupancy = sum(s.current_occupancy for s in db.query(models.Shelter).all())

    recent = (
        db.query(models.RiskAssessment)
        .order_by(models.RiskAssessment.created_at.desc())
        .limit(20)
        .all()
    )
    critical_count = sum(1 for r in recent if r.risk_level == models.RiskLevel.critical)
    high_count = sum(1 for r in recent if r.risk_level == models.RiskLevel.high)

    return {
        "total_sensors": total_sensors,
        "active_alerts": active_alerts,
        "total_shelters": total_shelters,
        "open_incident_reports": open_reports,
        "shelter_capacity": total_capacity,
        "shelter_occupancy": total_occupancy,
        "shelter_occupancy_pct": round((total_occupancy / total_capacity) * 100, 1) if total_capacity else 0,
        "recent_critical_risk_count": critical_count,
        "recent_high_risk_count": high_count,
    }
