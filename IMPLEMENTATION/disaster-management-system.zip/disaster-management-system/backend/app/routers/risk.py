from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas

router = APIRouter(prefix="/risk", tags=["Risk Assessment"])


@router.get("/", response_model=List[schemas.RiskOut])
def list_risk_assessments(
    limit: int = Query(50, le=500),
    disaster_type: Optional[str] = None,
    db: Session = Depends(get_db),
):
    q = db.query(models.RiskAssessment)
    if disaster_type:
        q = q.filter(models.RiskAssessment.disaster_type == disaster_type)
    return q.order_by(models.RiskAssessment.created_at.desc()).limit(limit).all()


@router.get("/current", response_model=List[schemas.RiskOut])
def current_risk_by_region(db: Session = Depends(get_db)):
    """
    Returns the latest risk assessment per sensor -- i.e. the current
    risk picture used to drive the GIS affected-area map.
    """
    # Simple, DB-portable approach: pull recent assessments and keep the
    # first (most recent) one seen per sensor.
    all_assessments = (
        db.query(models.RiskAssessment)
        .order_by(models.RiskAssessment.created_at.desc())
        .all()
    )
    seen = set()
    latest = []
    for a in all_assessments:
        if a.sensor_id not in seen:
            latest.append(a)
            seen.add(a.sensor_id)
    return latest
