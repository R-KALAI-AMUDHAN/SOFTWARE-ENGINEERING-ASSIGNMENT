from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.ml.risk_model import predict_risk

router = APIRouter(prefix="/sensors", tags=["Sensors & Readings"])


@router.post("/", response_model=schemas.SensorOut, status_code=201)
def create_sensor(
    payload: schemas.SensorCreate,
    db: Session = Depends(get_db),
    _=Depends(auth.require_roles("authority", "admin")),
):
    sensor = models.Sensor(**payload.model_dump())
    db.add(sensor)
    db.commit()
    db.refresh(sensor)
    return sensor


@router.get("/", response_model=List[schemas.SensorOut])
def list_sensors(db: Session = Depends(get_db)):
    return db.query(models.Sensor).all()


@router.post("/{sensor_id}/readings", response_model=schemas.RiskOut, status_code=201)
def ingest_reading(sensor_id: int, payload: schemas.ReadingCreate, db: Session = Depends(get_db)):
    """
    Ingest a new sensor reading (from an IoT device / weather station /
    seismic sensor / simulator). Runs the reading through the AI/ML risk
    model and stores a RiskAssessment. This is the core "real-time
    prediction pipeline" of the system.
    """
    sensor = db.query(models.Sensor).filter(models.Sensor.id == sensor_id).first()
    if not sensor:
        raise HTTPException(status_code=404, detail="Sensor not found")

    reading = models.SensorReading(sensor_id=sensor_id, metric=payload.metric, value=payload.value)
    db.add(reading)

    disaster_type, risk_level, risk_score = predict_risk(payload.metric, payload.value)

    assessment = models.RiskAssessment(
        sensor_id=sensor_id,
        disaster_type=disaster_type,
        risk_level=risk_level,
        risk_score=risk_score,
        latitude=sensor.latitude,
        longitude=sensor.longitude,
        region=sensor.region,
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)
    return assessment


@router.get("/{sensor_id}/readings", response_model=List[schemas.ReadingOut])
def list_readings(sensor_id: int, db: Session = Depends(get_db)):
    return (
        db.query(models.SensorReading)
        .filter(models.SensorReading.sensor_id == sensor_id)
        .order_by(models.SensorReading.recorded_at.desc())
        .limit(100)
        .all()
    )
