"""
Optional helper to seed the database with a handful of demo sensors,
shelters, and an admin user so the frontend has something to display
immediately after `docker compose up`.

Run with:  docker compose exec backend python -m app.seed_data
"""
from app.database import SessionLocal, Base, engine
from app import models, auth

Base.metadata.create_all(bind=engine)

db = SessionLocal()

# --- Admin user ---
if not db.query(models.User).filter(models.User.email == "admin@disaster.gov").first():
    admin = models.User(
        name="System Admin",
        email="admin@disaster.gov",
        hashed_password=auth.hash_password("admin123"),
        role=models.UserRole.admin,
    )
    db.add(admin)

# --- Sensors (Chennai region as a representative example) ---
sensors = [
    {"name": "Adyar River Gauge", "sensor_type": "water_level", "latitude": 13.0012, "longitude": 80.2565, "region": "Adyar"},
    {"name": "Marina Coastal Weather Station", "sensor_type": "weather", "latitude": 13.0500, "longitude": 80.2824, "region": "Marina"},
    {"name": "Guindy Seismic Station", "sensor_type": "seismic", "latitude": 13.0067, "longitude": 80.2206, "region": "Guindy"},
    {"name": "Red Hills Forest Watch", "sensor_type": "fire", "latitude": 13.1985, "longitude": 80.1839, "region": "Red Hills"},
]

sensor_objs = []
for s in sensors:
    existing = db.query(models.Sensor).filter(models.Sensor.name == s["name"]).first()
    if not existing:
        obj = models.Sensor(**s)
        db.add(obj)
        db.flush()
        sensor_objs.append(obj)
    else:
        sensor_objs.append(existing)

# --- Shelters ---
shelters = [
    {"name": "Community Hall - Adyar", "latitude": 13.0060, "longitude": 80.2570, "capacity": 300, "current_occupancy": 40, "contact_phone": "+91-9000000001"},
    {"name": "Government School - Guindy", "latitude": 13.0100, "longitude": 80.2200, "capacity": 500, "current_occupancy": 120, "contact_phone": "+91-9000000002"},
    {"name": "Municipal Stadium - Red Hills", "latitude": 13.1950, "longitude": 80.1800, "capacity": 800, "current_occupancy": 0, "contact_phone": "+91-9000000003"},
]
for sh in shelters:
    if not db.query(models.Shelter).filter(models.Shelter.name == sh["name"]).first():
        db.add(models.Shelter(**sh))

db.commit()
db.close()
print("Seed data inserted successfully.")
