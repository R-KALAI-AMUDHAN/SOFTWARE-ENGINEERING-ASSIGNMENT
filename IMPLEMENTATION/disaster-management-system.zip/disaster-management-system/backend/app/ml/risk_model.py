"""
Lightweight disaster risk-prediction module.

For this small/demo implementation, each disaster type is scored by a
RandomForestClassifier trained (in train_model.py) on synthetic-but-
domain-informed data, e.g. rainfall/water-level for floods, wind speed
for cyclones, magnitude for earthquakes, temperature/humidity for
wildfires. Models are persisted with joblib. If a model file is
missing (e.g. first run before training), a rule-based threshold
fallback is used so the API never breaks.

This keeps the "AI/ML" component real (trained scikit-learn models)
while staying fast/cheap enough to run in a small container.
"""
import os
from typing import Tuple

import joblib
import numpy as np

MODEL_DIR = os.path.join(os.path.dirname(__file__), "models")

METRIC_TO_DISASTER = {
    "rainfall_mm": "flood",
    "water_level_m": "flood",
    "wind_kmph": "cyclone",
    "pressure_hpa": "cyclone",
    "magnitude": "earthquake",
    "temp_c": "wildfire",
    "humidity_pct": "wildfire",
}

RISK_LEVELS = ["low", "moderate", "high", "critical"]


def _fallback_score(metric: str, value: float) -> float:
    """Simple threshold-based fallback (0-1 score)."""
    thresholds = {
        "rainfall_mm": (20, 60, 120, 200),
        "water_level_m": (1, 2.5, 4, 6),
        "wind_kmph": (40, 70, 100, 150),
        "pressure_hpa": (1005, 995, 985, 970),  # lower pressure => higher risk
        "magnitude": (3.0, 4.5, 5.5, 7.0),
        "temp_c": (32, 38, 42, 47),
        "humidity_pct": (40, 25, 15, 8),  # lower humidity => higher wildfire risk
    }
    lo, mid, hi, crit = thresholds.get(metric, (25, 50, 75, 100))
    inverse = metric in ("pressure_hpa", "humidity_pct")
    v = value
    if inverse:
        if v >= lo:
            return 0.1
        elif v >= mid:
            return 0.35
        elif v >= hi:
            return 0.65
        elif v >= crit:
            return 0.85
        else:
            return 0.97
    else:
        if v < lo:
            return 0.1
        elif v < mid:
            return 0.35
        elif v < hi:
            return 0.65
        elif v < crit:
            return 0.85
        else:
            return 0.97


def _load_model(disaster_type: str):
    path = os.path.join(MODEL_DIR, f"{disaster_type}_model.joblib")
    if os.path.exists(path):
        return joblib.load(path)
    return None


_MODEL_CACHE = {}


def predict_risk(metric: str, value: float) -> Tuple[str, str, float]:
    """
    Given a sensor metric and its value, return
    (disaster_type, risk_level, risk_score in [0,1]).
    """
    disaster_type = METRIC_TO_DISASTER.get(metric, "flood")

    if disaster_type not in _MODEL_CACHE:
        _MODEL_CACHE[disaster_type] = _load_model(disaster_type)
    model = _MODEL_CACHE[disaster_type]

    if model is not None:
        try:
            proba = model.predict_proba(np.array([[value]]))[0]
            # proba is aligned with model.classes_ (0=low,1=moderate,2=high,3=critical)
            score = float(np.dot(proba, [0.15, 0.45, 0.75, 0.97]))
        except Exception:
            score = _fallback_score(metric, value)
    else:
        score = _fallback_score(metric, value)

    if score < 0.3:
        level = "low"
    elif score < 0.55:
        level = "moderate"
    elif score < 0.8:
        level = "high"
    else:
        level = "critical"

    return disaster_type, level, round(score, 3)
