"""
Trains small RandomForest classifiers per disaster type on synthetic,
domain-informed data, and saves them with joblib. Run at Docker build
time (see Dockerfile) so the API has real trained models available.

This is intentionally simple (single-feature classifiers) to keep the
demo implementation small and fast while still being a genuine,
trainable/retrainable ML component rather than a hardcoded if/else.
"""
import os
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import joblib

MODEL_DIR = os.path.join(os.path.dirname(__file__), "models")
os.makedirs(MODEL_DIR, exist_ok=True)

# (disaster_type, metric, value_range, breakpoints[low,mid,hi,crit], inverse)
CONFIGS = [
    ("flood", "rainfall_mm", (0, 250), (20, 60, 120, 200), False),
    ("cyclone", "wind_kmph", (0, 200), (40, 70, 100, 150), False),
    ("earthquake", "magnitude", (0, 9), (3.0, 4.5, 5.5, 7.0), False),
    ("wildfire", "temp_c", (10, 55), (32, 38, 42, 47), False),
]


def synth_dataset(value_range, breakpoints, inverse, n=4000, seed=42):
    rng = np.random.default_rng(seed)
    X = rng.uniform(value_range[0], value_range[1], size=(n, 1))
    y = []
    lo, mid, hi, crit = breakpoints
    for v in X[:, 0]:
        if inverse:
            if v >= lo:
                cls = 0
            elif v >= mid:
                cls = 1
            elif v >= hi:
                cls = 2
            else:
                cls = 3
        else:
            if v < lo:
                cls = 0
            elif v < mid:
                cls = 1
            elif v < hi:
                cls = 2
            else:
                cls = 3
        y.append(cls)
    y = np.array(y)
    # add label noise for realism
    noise_idx = rng.choice(n, size=int(n * 0.05), replace=False)
    y[noise_idx] = rng.integers(0, 4, size=len(noise_idx))
    return X, y


def main():
    for disaster_type, metric, value_range, breakpoints, inverse in CONFIGS:
        X, y = synth_dataset(value_range, breakpoints, inverse)
        clf = RandomForestClassifier(n_estimators=80, max_depth=6, random_state=42)
        clf.fit(X, y)
        out_path = os.path.join(MODEL_DIR, f"{disaster_type}_model.joblib")
        joblib.dump(clf, out_path)
        print(f"Trained + saved model for {disaster_type} ({metric}) -> {out_path}")


if __name__ == "__main__":
    main()
