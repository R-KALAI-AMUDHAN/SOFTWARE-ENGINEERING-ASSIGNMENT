// Backend API base URL. When served via docker-compose, the browser
// talks to the backend on localhost:8000 (published port), while
// server-to-server calls inside the compose network use the "backend"
// service name. Adjust if you deploy behind a different host/port.
const API_BASE = window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1"
  ? "http://localhost:8000"
  : `http://${window.location.hostname}:8000`;
