let authToken = localStorage.getItem("disaster_token") || null;
let authRole = localStorage.getItem("disaster_role") || null;

const dashMap = L.map("dash-map").setView([13.0827, 80.2707], 11);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(dashMap);
const riskColors = { low: "#16a34a", moderate: "#ca8a04", high: "#ea580c", critical: "#b91c1c" };

function authHeaders() {
  return authToken ? { Authorization: `Bearer ${authToken}` } : {};
}

function reflectLoginState() {
  const loginSection = document.getElementById("login-section");
  const loggedInSection = document.getElementById("logged-in-section");
  if (authToken) {
    loginSection.classList.add("hidden");
    loggedInSection.classList.remove("hidden");
    document.getElementById("current-user-role").textContent = authRole;
  } else {
    loginSection.classList.remove("hidden");
    loggedInSection.classList.add("hidden");
  }
}

document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const statusEl = document.getElementById("login-status");
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;
  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) throw new Error((await res.json()).detail || "Login failed");
    const data = await res.json();
    authToken = data.access_token;
    authRole = data.role;
    localStorage.setItem("disaster_token", authToken);
    localStorage.setItem("disaster_role", authRole);
    statusEl.textContent = "";
    document.getElementById("current-user-name").textContent = email;
    reflectLoginState();
  } catch (err) {
    statusEl.textContent = err.message;
    statusEl.className = "status-msg err";
  }
});

document.getElementById("logout-btn").addEventListener("click", () => {
  authToken = null;
  authRole = null;
  localStorage.removeItem("disaster_token");
  localStorage.removeItem("disaster_role");
  reflectLoginState();
});

async function fetchJSON(path, opts = {}) {
  const res = await fetch(`${API_BASE}${path}`, opts);
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || `Request failed: ${res.status}`);
  return res.json();
}

async function loadSummary() {
  try {
    const s = await fetchJSON("/dashboard/summary");
    document.getElementById("stat-sensors").textContent = s.total_sensors;
    document.getElementById("stat-alerts").textContent = s.active_alerts;
    document.getElementById("stat-shelters").textContent = s.total_shelters;
    document.getElementById("stat-reports").textContent = s.open_incident_reports;
  } catch (e) {
    console.warn(e);
  }
}

async function loadMapLayers() {
  try {
    const [sensors, shelters, risks, alerts] = await Promise.all([
      fetchJSON("/sensors/"),
      fetchJSON("/shelters/"),
      fetchJSON("/risk/current"),
      fetchJSON("/alerts/?active_only=true"),
    ]);

    const sensorSelect = document.getElementById("reading-sensor");
    sensorSelect.innerHTML = sensors.map((s) => `<option value="${s.id}">${s.name} (${s.sensor_type})</option>`).join("");

    sensors.forEach((s) => {
      L.marker([s.latitude, s.longitude]).addTo(dashMap).bindPopup(`<strong>${s.name}</strong><br/>Type: ${s.sensor_type}`);
    });
    shelters.forEach((s) => {
      L.circleMarker([s.latitude, s.longitude], { radius: 7, color: "#1d4ed8", fillOpacity: 0.9 })
        .addTo(dashMap)
        .bindPopup(`<strong>${s.name}</strong><br/>${s.current_occupancy}/${s.capacity} occupied`);
    });
    risks.forEach((r) => {
      L.circle([r.latitude, r.longitude], {
        radius: 1500,
        color: riskColors[r.risk_level] || "#6b7280",
        fillOpacity: 0.2,
      }).addTo(dashMap);
    });
    alerts.forEach((a) => {
      if (a.latitude && a.longitude) {
        L.circle([a.latitude, a.longitude], {
          radius: (a.radius_km || 10) * 1000,
          color: "#b91c1c",
          dashArray: "6,4",
          fillOpacity: 0.05,
        }).addTo(dashMap);
      }
    });
  } catch (e) {
    console.warn("Map layer load failed", e);
  }
}

async function loadRiskTable() {
  const tbody = document.getElementById("risk-table-body");
  try {
    const risks = await fetchJSON("/risk/?limit=20");
    if (!risks.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="muted">No risk assessments yet — submit a sensor reading below.</td></tr>`;
      return;
    }
    tbody.innerHTML = risks
      .map(
        (r) => `
      <tr>
        <td>${r.disaster_type}</td>
        <td><span class="badge ${r.risk_level}">${r.risk_level}</span></td>
        <td>${r.risk_score}</td>
        <td>${r.region || "-"}</td>
        <td>${new Date(r.created_at).toLocaleString()}</td>
      </tr>`
      )
      .join("");
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="5" class="muted">Failed to load (${e.message})</td></tr>`;
  }
}

async function loadReportsTable() {
  const tbody = document.getElementById("reports-table-body");
  try {
    const reports = await fetchJSON("/reports/");
    if (!reports.length) {
      tbody.innerHTML = `<tr><td colspan="4" class="muted">No citizen reports yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = reports
      .map(
        (r) => `
      <tr>
        <td>${r.category}</td>
        <td>${r.description || "-"}</td>
        <td>${r.status}</td>
        <td>
          ${
            r.status !== "resolved"
              ? `<button class="secondary" style="width:auto;padding:4px 10px;font-size:0.75rem;" onclick="resolveReport(${r.id})">Mark Resolved</button>`
              : "-"
          }
        </td>
      </tr>`
      )
      .join("");
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="4" class="muted">Failed to load (${e.message})</td></tr>`;
  }
}

async function resolveReport(id) {
  try {
    await fetchJSON(`/reports/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify({ status: "resolved" }),
    });
    loadReportsTable();
  } catch (e) {
    alert(`Failed to update report (are you logged in as authority/responder?): ${e.message}`);
  }
}
window.resolveReport = resolveReport;

document.getElementById("alert-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const statusEl = document.getElementById("alert-status");
  const payload = {
    title: document.getElementById("alert-title").value,
    message: document.getElementById("alert-message").value,
    disaster_type: document.getElementById("alert-type").value,
    risk_level: document.getElementById("alert-level").value,
    region: document.getElementById("alert-region").value,
    latitude: parseFloat(document.getElementById("alert-lat").value),
    longitude: parseFloat(document.getElementById("alert-lng").value),
    radius_km: 10,
    channels: "app,sms,email",
  };
  try {
    await fetchJSON("/alerts/", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(payload),
    });
    statusEl.textContent = "✅ Alert dispatched via app, SMS & email.";
    statusEl.className = "status-msg ok";
    e.target.reset();
    loadSummary();
  } catch (err) {
    statusEl.textContent = `Failed (login as authority/admin required): ${err.message}`;
    statusEl.className = "status-msg err";
  }
});

document.getElementById("reading-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const statusEl = document.getElementById("reading-status");
  const sensorId = document.getElementById("reading-sensor").value;
  const payload = {
    metric: document.getElementById("reading-metric").value,
    value: parseFloat(document.getElementById("reading-value").value),
  };
  try {
    const result = await fetchJSON(`/sensors/${sensorId}/readings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    statusEl.textContent = `Predicted: ${result.disaster_type} risk = ${result.risk_level} (score ${result.risk_score})`;
    statusEl.className = "status-msg ok";
    loadRiskTable();
    loadSummary();
  } catch (err) {
    statusEl.textContent = `Failed: ${err.message}`;
    statusEl.className = "status-msg err";
  }
});

reflectLoginState();
loadSummary();
loadMapLayers();
loadRiskTable();
loadReportsTable();
