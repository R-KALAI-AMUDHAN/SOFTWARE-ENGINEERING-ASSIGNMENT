// ---------- Map setup ----------
const map = L.map("map").setView([13.0827, 80.2707], 11); // Default: Chennai
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(map);

const riskColors = { low: "#16a34a", moderate: "#ca8a04", high: "#ea580c", critical: "#b91c1c" };

let userMarker = null;

async function fetchJSON(path) {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  return res.json();
}

// ---------- Alerts ----------
async function loadAlerts() {
  const listEl = document.getElementById("alerts-list");
  try {
    const alerts = await fetchJSON("/alerts/?active_only=true");
    if (!alerts.length) {
      listEl.innerHTML = `<p class="muted">No active alerts right now.</p>`;
      return;
    }
    listEl.innerHTML = alerts
      .map(
        (a) => `
      <div class="alert-box">
        <h4>${a.title} <span class="badge ${a.risk_level}">${a.risk_level}</span></h4>
        <p>${a.message}</p>
        <div class="meta">${a.disaster_type.toUpperCase()} · ${a.region || "Region N/A"} · via ${a.channels}</div>
      </div>`
      )
      .join("");

    alerts.forEach((a) => {
      if (a.latitude && a.longitude) {
        L.circle([a.latitude, a.longitude], {
          radius: (a.radius_km || 10) * 1000,
          color: riskColors[a.risk_level] || "#b91c1c",
          fillOpacity: 0.15,
        })
          .addTo(map)
          .bindPopup(`<strong>${a.title}</strong><br/>${a.message}`);
      }
    });
  } catch (e) {
    listEl.innerHTML = `<p class="muted">Could not load alerts (${e.message}). Is the backend running?</p>`;
  }
}

// ---------- Shelters ----------
async function loadShelters() {
  const tbody = document.getElementById("shelters-table-body");
  try {
    const shelters = await fetchJSON("/shelters/");
    if (!shelters.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="muted">No shelters registered yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = shelters
      .map(
        (s) => `
      <tr>
        <td>${s.name}</td>
        <td>${s.status}</td>
        <td>${s.current_occupancy} / ${s.capacity}</td>
        <td>${s.food_supplies}</td>
        <td>${s.medical_supplies}</td>
        <td>${s.contact_phone || "-"}</td>
      </tr>`
      )
      .join("");

    shelters.forEach((s) => {
      L.marker([s.latitude, s.longitude], {
        icon: L.divIcon({
          className: "",
          html: `<div style="background:#1d4ed8;color:white;border-radius:50%;width:14px;height:14px;border:2px solid white;"></div>`,
        }),
      })
        .addTo(map)
        .bindPopup(`<strong>${s.name}</strong><br/>Status: ${s.status}<br/>Occupancy: ${s.current_occupancy}/${s.capacity}`);
    });
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="6" class="muted">Could not load shelters (${e.message})</td></tr>`;
  }
}

// ---------- Risk sensors on map ----------
async function loadRiskLayer() {
  try {
    const risks = await fetchJSON("/risk/current");
    risks.forEach((r) => {
      L.circleMarker([r.latitude, r.longitude], {
        radius: 8,
        color: riskColors[r.risk_level] || "#6b7280",
        fillColor: riskColors[r.risk_level] || "#6b7280",
        fillOpacity: 0.9,
      })
        .addTo(map)
        .bindPopup(
          `<strong>${r.disaster_type.toUpperCase()} risk</strong><br/>Level: ${r.risk_level} (score ${r.risk_score})<br/>${r.region || ""}`
        );
    });
  } catch (e) {
    console.warn("Could not load risk layer", e);
  }
}

// ---------- Incident reporting ----------
document.getElementById("use-location-btn").addEventListener("click", () => {
  if (!navigator.geolocation) {
    alert("Geolocation not supported by this browser.");
    return;
  }
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      document.getElementById("report-lat").value = pos.coords.latitude.toFixed(5);
      document.getElementById("report-lng").value = pos.coords.longitude.toFixed(5);
      map.setView([pos.coords.latitude, pos.coords.longitude], 13);
      if (userMarker) map.removeLayer(userMarker);
      userMarker = L.marker([pos.coords.latitude, pos.coords.longitude]).addTo(map).bindPopup("You are here");
    },
    () => alert("Could not get your location. Please enter coordinates manually.")
  );
});

document.getElementById("report-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const statusEl = document.getElementById("report-status");
  const payload = {
    category: document.getElementById("report-category").value,
    description: document.getElementById("report-description").value,
    latitude: parseFloat(document.getElementById("report-lat").value),
    longitude: parseFloat(document.getElementById("report-lng").value),
  };
  if (Number.isNaN(payload.latitude) || Number.isNaN(payload.longitude)) {
    statusEl.textContent = "Please provide latitude and longitude (or use your current location).";
    statusEl.className = "status-msg err";
    return;
  }
  try {
    const res = await fetch(`${API_BASE}/reports/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(await res.text());
    statusEl.textContent = "✅ Report submitted. Emergency teams have been notified.";
    statusEl.className = "status-msg ok";
    e.target.reset();
  } catch (err) {
    statusEl.textContent = `Failed to submit report: ${err.message}`;
    statusEl.className = "status-msg err";
  }
});

loadAlerts();
loadShelters();
loadRiskLayer();
