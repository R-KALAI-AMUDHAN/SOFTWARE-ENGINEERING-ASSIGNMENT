# Sprint Plan (Scrum)

Team assumed: 1 Product Owner, 1 Scrum Master, 3-4 Developers. Sprint length: 2 weeks.
This build corresponds to the working software produced across Sprints 0-3 below;
Sprints 4-5 describe planned future work (see `product_backlog.md` Should/Could items).

## Sprint 0 — Project Setup & Requirements (1 week, spike)
**Goal:** Establish shared understanding of scope and get the team able to build.
- Stakeholder interviews → draft personas: Citizen, Disaster Management Authority,
  Emergency Response Agency, Administrator
- Draft use-case diagram and initial backlog
- Repo, Docker Compose skeleton, CI-friendly project layout
- Tech-stack decision: FastAPI + PostgreSQL + Leaflet/JS + scikit-learn + Docker

**Sprint Review outcome:** Backlog, MoSCoW list, use-case diagram, empty
but running "Hello World" Docker Compose stack.

## Sprint 1 — Foundation: Auth, Sensors, Data Model
**Sprint Goal:** *"Authorized users can register sensors and the system can
store real-time sensor readings."*
- Data model for users/sensors/readings (SQLAlchemy models)
- JWT auth + RBAC (`citizen`, `authority`, `responder`, `admin`)
- Sensor CRUD + reading ingestion endpoint
- Dockerize backend + Postgres

**Definition of Done:** Endpoints pass manual Swagger tests; RBAC verified
(403 for unauthorized roles); containers start via `docker compose up`.

## Sprint 2 — AI/ML Risk Prediction + Alerts
**Sprint Goal:** *"Incoming sensor data automatically produces a risk
assessment, and authorities can issue alerts based on it."*
- Train RandomForest risk classifiers per disaster type (synthetic,
  domain-informed data) + threshold fallback
- Wire reading ingestion → automatic risk assessment persistence
- Alerts API (create/list/deactivate), RBAC-protected creation
- `/risk/current` and `/risk/` endpoints for the dashboard/map

**Definition of Done:** Submitting a high-value reading (e.g. rainfall
180mm) produces a `high`/`critical` risk record automatically; alert
creation restricted to authority/admin.

## Sprint 3 — GIS, Shelters, Citizen Reporting, Dashboard (this build's final sprint)
**Sprint Goal:** *"Citizens and authorities have a usable, map-based
end-to-end experience."*
- Leaflet-based citizen app: live map (alerts/shelters/risk), alert feed,
  incident report form with geolocation
- Shelter CRUD + occupancy/resource tracking, shown on map + table
- Authority dashboard: login, summary stats, risk table, incident triage,
  alert issuance form, sensor-reading simulator
- `docker-compose.yml` finalized (db + backend + frontend), seed script

**Definition of Done:** Full user journey works end-to-end locally via
`docker compose up --build` + seed script, as documented in `README.md`.

---

## Planned Future Sprints (backlog, not yet built)

## Sprint 4 — Evacuation Routing & Real Notification Gateway
**Sprint Goal:** *"Citizens get an actual recommended evacuation route, and
alerts really reach SMS/email/push channels."*
- Integrate a routing engine (e.g. OSRM) for shortest-safe-path to nearest
  open shelter, avoiding risk zones/blocked roads (from citizen reports)
- Integrate real SMS (Twilio), email (SES/SMTP), and push (FCM) providers
- Retire simulated "channels" field in favor of delivery status tracking

## Sprint 5 — Multi-Agency Coordination & Real ML Training Data
**Sprint Goal:** *"Agencies coordinate on shared tasks, and predictions use
real historical data."*
- Task assignment workflow across police/fire/medical/relief teams
- Replace synthetic ML training data with historical datasets (e.g. IMD
  rainfall records, USGS seismic data, NOAA cyclone tracks)
- Add model evaluation/monitoring (precision/recall per disaster type)

---

## Scrum Ceremonies (how this team would run them)
- **Daily Standup:** 15 min, what I did / will do / blockers
- **Sprint Planning:** at start of each sprint, break sprint goal into tasks
  sized in story points, pulled from the top of the prioritized backlog
- **Sprint Review:** demo working software to stakeholders (Product Owner +
  simulated end users) at end of sprint
- **Sprint Retrospective:** what went well / what to improve / action items
