# Architecture

## 1. Component overview

```
Browser (Citizen App / Authority Dashboard)
   │  HTML + vanilla JS + Leaflet.js (GIS)
   ▼
Nginx (frontend container, port 8080)
   │  static file serving only — all data via REST calls to backend
   ▼
FastAPI backend (port 8000)
   ├── auth.py         → JWT issuance/validation, password hashing, RBAC dependency
   ├── routers/
   │     ├── users.py     → register/login/me
   │     ├── sensors.py   → sensor CRUD + reading ingestion (triggers ML)
   │     ├── risk.py      → risk assessment history / latest-per-sensor
   │     ├── alerts.py    → multi-channel alert CRUD (RBAC: authority/admin)
   │     ├── shelters.py  → shelter CRUD + occupancy/resource updates
   │     ├── reports.py   → citizen incident reports + status updates
   │     └── dashboard.py → aggregated summary stats
   ├── ml/
   │     ├── train_model.py → trains RandomForest per disaster type (build-time)
   │     └── risk_model.py  → loads trained models, predicts risk (runtime)
   └── models.py / schemas.py / database.py → SQLAlchemy ORM + Pydantic + DB session
   ▼
PostgreSQL (port 5432) — persistent store for all entities
```

## 2. Data model (entities)

| Entity | Key fields | Notes |
|---|---|---|
| `User` | name, email, hashed_password, role, phone | role ∈ {citizen, authority, responder, admin} |
| `Sensor` | name, sensor_type, latitude, longitude, region | sensor_type ∈ {weather, seismic, water_level, fire, ...} |
| `SensorReading` | sensor_id, metric, value, recorded_at | raw ingested data point |
| `RiskAssessment` | sensor_id, disaster_type, risk_level, risk_score, lat/lng, region | produced automatically per reading by the ML pipeline |
| `Alert` | title, message, disaster_type, risk_level, region, lat/lng, radius_km, channels, is_active | authority/admin-issued; channels = comma list (app,sms,email) |
| `Shelter` | name, lat/lng, capacity, current_occupancy, food_supplies, medical_supplies, status | status ∈ {open, full, closed} |
| `IncidentReport` | reporter_id (nullable), category, description, lat/lng, status | status ∈ {open, in_progress, resolved} |

Entity-relationship summary:
- `Sensor 1—N SensorReading`
- `Sensor 1—N RiskAssessment` (assessment snapshots the sensor's location/region at prediction time)
- `User 1—N IncidentReport` (optional; anonymous reports allowed)
- `Alert`, `Shelter` are independent top-level entities referenced by lat/lng for map rendering

## 3. Real-time sensor-data collection

`POST /sensors/{id}/readings` is the ingestion endpoint. It's intentionally
open (no auth) so that field devices, weather-station feeds, or a simple
simulator/cron job can push data without managing device credentials in
this small build. In production this would be tightened with device API
keys / mTLS and likely message-queue buffering (e.g. MQTT → Kafka →
consumer) for high sensor volume; the current synchronous REST endpoint is
sufficient for the assignment's demo scale.

## 4. AI/ML risk prediction pipeline

1. A reading arrives with a `metric` (e.g. `rainfall_mm`) and `value`.
2. `METRIC_TO_DISASTER` maps the metric to a disaster type (flood, cyclone,
   earthquake, wildfire).
3. A per-disaster-type `RandomForestClassifier` (trained in
   `train_model.py` on synthetic, domain-informed data at Docker build
   time) predicts class probabilities; these are converted into a
   continuous `risk_score` (0-1) and bucketed into `low/moderate/high/critical`.
4. If a model file is missing, a deterministic threshold-based fallback
   (`_fallback_score`) guarantees the API never breaks.
5. The resulting `RiskAssessment` is persisted with the sensor's
   coordinates, so it can be drawn directly as a GIS risk-zone marker.

This design keeps the ML layer real and swappable: replacing
`train_model.py`'s synthetic data generator with a loader for actual
historical datasets (IMD rainfall, USGS seismic, NOAA cyclone tracks, etc.)
requires no changes to the prediction API contract.

## 5. GIS-based mapping

The frontend uses Leaflet.js with OpenStreetMap tiles (no API key
required, good for a self-contained demo). Layers rendered:
- **Sensors** — plain markers
- **Risk zones** — colored circles at sensor coordinates, colored by
  `risk_level` (green/yellow/orange/red)
- **Alerts** — larger circles (radius = `radius_km`) showing the
  authority-declared affected area
- **Shelters** — blue circle markers with occupancy popup

Evacuation-route optimization (shortest safe path from a citizen's
location to the nearest open, non-overloaded shelter, avoiding
authority-declared risk zones and citizen-reported blocked roads) is
scoped as a Should-have (`docs/product_backlog.md` #10) — the data needed
to build it (shelter status, risk zones, blocked-road reports) is already
modeled and exposed by the API.

## 6. Multi-channel alerts

`Alert.channels` records which channels an alert was (simulated to be)
dispatched through. Swapping in real providers is isolated to
`backend/app/routers/alerts.py::create_alert` — e.g. call Twilio for SMS,
SES/SMTP for email, and FCM for push, then record delivery status.

## 7. Security / RBAC

- Passwords hashed with bcrypt (`passlib`).
- JWT bearer tokens (`python-jose`), 12-hour expiry by default.
- `require_roles(*roles)` FastAPI dependency enforces role checks on
  sensitive endpoints (sensor/alert/shelter/report-status mutations).
- CORS is open (`*`) for this demo; restrict to known frontend origins in
  production.

## 8. Cloud / scalability notes

This demo runs as three Docker Compose services. To scale toward the
"cloud computing... scalable data storage and processing" objective in
the brief:
- Backend is stateless (JWT-based) → horizontally scalable behind a load
  balancer / API gateway.
- PostgreSQL can be swapped for a managed cloud DB (e.g. RDS/Cloud SQL) by
  changing `DATABASE_URL`.
- High-volume sensor ingestion would move from synchronous REST to a
  message queue (Kafka/MQTT) with worker consumers feeding the ML
  pipeline and DB.
- Static frontend can be served from an object-storage + CDN (S3 +
  CloudFront, etc.) instead of the Nginx container.
