# Scrum Board (Snapshot — End of Sprint 3)

Recommended to mirror this as a GitHub Projects (Kanban) board with columns
below, one card per backlog item / user story, linked to its feature branch
and PR.

## To Do (Backlog, prioritized)
- [ ] Evacuation route optimization engine (Should)
- [ ] Real SMS/email/push gateway integration (Should)
- [ ] Historical dataset ML retraining pipeline (Should)
- [ ] Multi-agency task assignment workflow (Should)
- [ ] Native/PWA mobile app (Could)
- [ ] Traffic-aware routing (Could)
- [ ] Satellite imagery ingestion (Could)
- [ ] Post-disaster analytics/reporting (Could)
- [ ] Multilingual support (Could)

## In Progress
*(empty at end of Sprint 3 — all committed items completed)*

## In Review
*(empty at end of Sprint 3 — all PRs merged)*

## Done (Sprint 0-3)
- [x] Repo & Docker Compose skeleton
- [x] Use-case diagram & initial backlog
- [x] Data model (users, sensors, readings, risk assessments, alerts, shelters, reports)
- [x] JWT auth + RBAC (citizen/authority/responder/admin)
- [x] Sensor registration & reading ingestion API
- [x] AI/ML risk classifiers (flood/cyclone/earthquake/wildfire) + auto risk assessment on ingestion
- [x] Alerts API (create/list/deactivate) with RBAC
- [x] `/risk/current` + `/risk/` endpoints
- [x] Shelter CRUD + occupancy/resource tracking
- [x] Citizen incident reporting API + form
- [x] Leaflet GIS map (sensors, risk zones, shelters, alerts)
- [x] Citizen app (alerts feed, shelter table, report form)
- [x] Authority dashboard (login, stats, risk table, incident triage, alert form, reading simulator)
- [x] Seed script for demo data
- [x] `docker-compose.yml` (db + backend + frontend)
- [x] README + Agile documentation set

## Sample Task Breakdown (Sprint 2, for illustration)
| Task | Owner (role) | Est. (SP) | Status |
|---|---|---|---|
| Design risk_assessments table & migrations | Backend Dev | 2 | Done |
| Build synthetic training-data generator | ML Dev | 3 | Done |
| Train + persist RandomForest models per disaster type | ML Dev | 3 | Done |
| Wire `/sensors/{id}/readings` to call risk model | Backend Dev | 2 | Done |
| Build `/alerts` CRUD with RBAC | Backend Dev | 3 | Done |
| Write unit/manual test plan for risk thresholds | QA / Dev | 2 | Done |
