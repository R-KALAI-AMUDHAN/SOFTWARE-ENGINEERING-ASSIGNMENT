# MoSCoW Prioritization

## Must Have (delivered in this build)
- User authentication with role-based access control (citizen, authority, responder, admin)
- Sensor registration and real-time reading ingestion
- AI/ML-based disaster risk prediction (flood, cyclone, earthquake, wildfire)
- GIS map showing sensors, risk zones, shelters, and alerts
- Location-specific alert creation and citizen-facing alert feed
- Shelter registration and occupancy/resource tracking
- Citizen incident reporting with geolocation
- Authority/responder dashboard with real-time summary stats
- Containerized deployment via Docker Compose

## Should Have (near-term backlog, not yet built)
- GIS-based automatic evacuation route recommendation (shortest safe path to an open shelter)
- Real SMS/email/push notification gateway integration (currently simulated)
- Training risk models on real historical disaster datasets instead of synthetic data
- Shared multi-agency task assignment workflow (police/fire/medical/relief)

## Could Have (future backlog)
- Native/PWA mobile app with offline alert caching
- Live traffic-aware evacuation routing
- Satellite/remote-sensing imagery ingestion for flood/wildfire extent detection
- Post-disaster analytics and resource-utilization reporting
- Multilingual citizen app and alerts

## Won't Have (this phase)
- Offline-first data sync for low-connectivity field responders
- Drone/robot-based automated damage assessment integration

## Rationale
Must-haves were selected because they represent the minimum end-to-end
slice needed to demonstrate the *entire* pipeline described in the problem
statement — sensing → AI prediction → alerting → GIS mapping → shelter
resource visibility → citizen reporting → authority coordination — with
working authentication and containerization, so the system is genuinely
usable and demoable, not just a set of disconnected features.
