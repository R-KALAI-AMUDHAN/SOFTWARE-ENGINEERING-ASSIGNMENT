# Use Case Diagram

Rendered with Mermaid (view on GitHub, or paste into https://mermaid.live).

```mermaid
graph LR
  Citizen((Citizen))
  Authority((Disaster Mgmt<br/>Authority))
  Responder((Emergency Response<br/>Agency))
  Admin((System Admin))
  Sensor((IoT / Weather /<br/>Seismic Sensor))

  subgraph System["Intelligent Disaster Early Warning & Evacuation Management System"]
    UC1[View real-time alerts]
    UC2[Locate nearby shelters]
    UC3[Report incident]
    UC4[View evacuation guidance]
    UC5[Register / Login]
    UC6[Monitor risk assessments]
    UC7[Issue multi-channel alert]
    UC8[Manage shelters & resources]
    UC9[Triage incident reports]
    UC10[View authority dashboard]
    UC11[Register / manage sensors]
    UC12[Manage users & roles]
    UC13[Ingest sensor reading]
    UC14[AI/ML risk prediction]
  end

  Citizen --> UC1
  Citizen --> UC2
  Citizen --> UC3
  Citizen --> UC4
  Citizen --> UC5

  Authority --> UC5
  Authority --> UC6
  Authority --> UC7
  Authority --> UC8
  Authority --> UC10
  Authority --> UC11

  Responder --> UC5
  Responder --> UC9
  Responder --> UC8
  Responder --> UC10

  Admin --> UC12
  Admin --> UC11
  Admin --> UC5

  Sensor --> UC13
  UC13 --> UC14
  UC14 --> UC6
```

## Actor descriptions

| Actor | Description |
|---|---|
| **Citizen** | General public in disaster-prone areas. Uses the mobile/web citizen app to receive alerts, find shelters, get evacuation guidance, and report incidents. |
| **Disaster Management Authority** | Government/municipal officials responsible for monitoring risk and issuing alerts, and overseeing shelter resources. |
| **Emergency Response Agency** | Police, fire & rescue, medical teams, relief organizations. Triage citizen reports, coordinate response, update shelter status. |
| **System Administrator** | Manages users/roles and sensor infrastructure, and ensures the platform runs securely. |
| **IoT / Weather / Seismic Sensor** | Automated (or simulated) data sources feeding real-time readings into the system, triggering AI/ML risk prediction. |

## Key use-case notes
- **Ingest sensor reading → AI/ML risk prediction** is an `<<include>>`
  relationship: every reading ingestion always triggers a risk assessment
  (implemented in `backend/app/routers/sensors.py` calling
  `backend/app/ml/risk_model.py`).
- **Issue multi-channel alert** is only accessible to Authority/Admin roles
  (RBAC-enforced via `require_roles` dependency).
- **Report incident** is accessible without login (anonymous reporting) to
  minimize friction during emergencies, but could optionally be linked to a
  logged-in citizen account.
