# Product Backlog

Prioritized (top = highest priority). Each item maps to one or more user
stories in `user_stories.md` and a MoSCoW category in `moscow_prioritization.md`.

| # | Epic | Backlog Item | Priority | Status |
|---|------|--------------|----------|--------|
| 1 | Platform Foundation | Set up repo, Docker Compose skeleton (db/backend/frontend), CI-ready structure | Must | Done |
| 2 | Auth & RBAC | User registration/login (citizen/authority/responder/admin), JWT auth | Must | Done |
| 3 | Sensor Data Ingestion | Sensor registration + reading ingestion API (weather/seismic/water-level/fire) | Must | Done |
| 4 | AI/ML Risk Prediction | Train + serve per-disaster-type risk classifiers; risk assessment persisted per reading | Must | Done |
| 5 | GIS Mapping | Interactive map showing sensors, risk zones, shelters, alerts (Leaflet) | Must | Done |
| 6 | Alerts | Authority-issued, location-specific, multi-channel alert records + citizen alert feed | Must | Done |
| 7 | Shelter Management | Shelter CRUD, occupancy/food/medical status tracking | Must | Done |
| 8 | Citizen Reporting | Citizen incident reporting (blocked roads, people needing help, etc.) with map coordinates | Must | Done |
| 9 | Authority Dashboard | Real-time summary stats, risk table, incident triage, alert issuance | Must | Done |
| 10 | Evacuation Routing | GIS-based evacuation route recommendation engine (shortest-safe-path to open shelter) | Should | Backlog |
| 11 | Notification Gateway | Real SMS/email/push integration (Twilio/SES/FCM) replacing simulated channels | Should | Backlog |
| 12 | Historical ML Training | Replace synthetic training data with real historical disaster datasets (IMD/USGS/NOAA) | Should | Backlog |
| 13 | Multi-agency Coordination | Shared incident/task board for police, fire, medical, relief orgs with assignment workflow | Should | Backlog |
| 14 | Mobile App | Native/PWA citizen mobile app with offline alert caching | Could | Backlog |
| 15 | Traffic-aware Routing | Incorporate live road/traffic conditions into evacuation routing | Could | Backlog |
| 16 | Satellite Imagery Ingestion | Ingest satellite/remote-sensing feeds for wildfire/flood extent detection | Could | Backlog |
| 17 | Analytics & Reporting | Post-disaster analytics, response-time reports, resource-utilization reports | Could | Backlog |
| 18 | Multilingual Support | Localize citizen app and alerts into regional languages | Could | Backlog |
| 19 | Offline-first Sync | Local caching + sync for responders in low-connectivity zones | Won't (this phase) | Backlog |
| 20 | Drone/Robot Integration | Automated aerial damage assessment integration | Won't (this phase) | Backlog |

## Definition of Done (per backlog item)
- Code implemented and containerized (where applicable)
- API documented (OpenAPI/Swagger auto-generated for backend items)
- Manually tested happy-path + at least one failure path
- Merged via reviewed Pull Request into `main`
- README/docs updated if behavior or setup changed
