# Git / GitHub Workflow

## Branching model
- `main` — always deployable; protected branch.
- `feature/<short-description>` — one branch per backlog item / user
  story, e.g. `feature/evacuation-route-optimizer`,
  `feature/sms-gateway-integration`, `feature/shelter-resource-tracking`.
- `fix/<short-description>` — bug fixes.

## Suggested commit history for this initial build (illustrative)
```
feat: scaffold docker-compose (db/backend/frontend)
feat: add SQLAlchemy models and Pydantic schemas
feat: add JWT auth + RBAC dependency
feat: add sensor registration + reading ingestion API
feat: train synthetic RandomForest risk classifiers per disaster type
feat: wire reading ingestion to AI/ML risk prediction pipeline
feat: add alerts API with RBAC-protected creation
feat: add shelter CRUD + resource tracking API
feat: add citizen incident reporting API
feat: add dashboard summary endpoint
feat: build citizen app (Leaflet map, alerts feed, report form)
feat: build authority dashboard (login, stats, risk table, alert form)
docs: add product backlog, user stories, MoSCoW, sprint plan, use-case diagram
chore: add seed script and README
```

## Pull Request checklist (template)
- [ ] Linked to a backlog item / user story
- [ ] Builds and runs via `docker compose up --build`
- [ ] New/changed endpoints manually tested via `/docs` (Swagger UI)
- [ ] RBAC verified for any new protected endpoint
- [ ] README/docs updated if setup or behavior changed
- [ ] At least one reviewer approval before merge

## Code review focus areas
- Correctness of RBAC on sensitive endpoints (alerts, sensors, shelter/report mutations)
- Data validation via Pydantic schemas
- No secrets committed (JWT secret / DB password come from environment variables)
- Consistent API response shapes (Pydantic `response_model`)

## Project board
Mirror `docs/scrum_board.md` as a GitHub Projects (Kanban) board with
columns: `To Do`, `In Progress`, `In Review`, `Done`. Link each card to its
issue and PR.
