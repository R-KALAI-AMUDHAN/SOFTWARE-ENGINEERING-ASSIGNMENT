# User Stories

Grouped by persona. Format: **As a** &lt;role&gt;, **I want** &lt;capability&gt;,
**so that** &lt;benefit&gt;. Acceptance criteria included for the stories
implemented in this build.

## Citizen

**US-01: Receive location-specific alerts**
As a citizen, I want to see active disaster alerts for my area, so that I
can evacuate or take precautions in time.
- AC: Citizen app shows all active alerts with disaster type, risk level,
  message, and affected zone on a map.
- AC: Alert list updates without requiring the user to know any technical
  region codes.

**US-02: Locate nearby shelters**
As a citizen, I want to see nearby emergency shelters and their status, so
that I know where to go and whether it has space/food/medical supplies.
- AC: Shelter list/map shows name, occupancy vs. capacity, food/medical
  status, and contact number.

**US-03: Report an incident**
As a citizen, I want to report a blocked road, a person needing help, a
fire, or rising flood water with my location, so that responders can act on
it quickly.
- AC: Report form captures category, description, and lat/lng (via
  "use my location" or manual entry).
- AC: Report is immediately visible to authorities/responders.

**US-04: View evacuation guidance** *(partially implemented)*
As a citizen, I want a recommended evacuation route to the nearest safe
shelter, so that I can move quickly and safely.
- Status: shelters + risk zones are shown on the map today; automatic
  routing is in the Should-have backlog (`docs/product_backlog.md` #10).

## Disaster Management Authority

**US-05: Monitor real-time risk levels**
As an authority, I want to see AI/ML-predicted risk levels across
monitored regions, so that I can decide when and where to issue alerts.
- AC: Dashboard lists recent risk assessments with disaster type, level,
  score, region, and timestamp.

**US-06: Issue multi-channel alerts**
As an authority, I want to issue a location-specific alert that citizens
see immediately, so that affected communities are warned as fast as
possible.
- AC: Only `authority`/`admin` roles can create alerts (RBAC-enforced).
- AC: Alert appears on the citizen app's map and list right after creation.

**US-07: Track shelters and resources**
As an authority, I want to see shelter occupancy, food, and medical supply
status across all shelters, so that I can allocate resources to where
they're needed.
- AC: Shelters list shows capacity, current occupancy, food/medical status.
- AC: Authority/admin/responder can update shelter status.

## Emergency Response Agency (Police / Fire / Medical / Relief)

**US-08: Triage citizen incident reports**
As a responder, I want to see incoming citizen incident reports and mark
them in-progress/resolved, so that my team coordinates work and avoids
duplicate effort.
- AC: Reports table shows category, description, status.
- AC: Responder/authority/admin can change report status
  (`open → in_progress → resolved`).

**US-09: Coordinate across agencies** *(partially implemented)*
As a responder, I want a shared operational picture (map + incident list +
shelter status) with other agencies, so that we don't duplicate or miss
work.
- Status: the shared dashboard/map provides a common operating picture
  today; dedicated task-assignment workflow is in the Should-have backlog
  (`docs/product_backlog.md` #13).

## System Administrator

**US-10: Manage users and roles**
As an admin, I want to register users with specific roles (citizen,
authority, responder, admin), so that access to sensitive actions is
properly controlled.
- AC: Registration accepts a role; invalid roles fall back to `citizen`.
- AC: JWT includes role; protected endpoints reject unauthorized roles
  with `403`.

**US-11: Manage sensors**
As an admin/authority, I want to register and manage IoT/weather/seismic
sensors with their locations, so that the system has accurate real-time
data sources feeding the risk model.
- AC: Only `authority`/`admin` can create sensors.
- AC: Anyone can list sensors (for map display); reading ingestion is open
  to feed data from field devices/simulators.

**US-12: Secure the platform**
As an admin, I want role-based access control and hashed credentials, so
that sensitive operations (alerts, sensor management) can't be performed
by unauthorized users.
- AC: Passwords stored with bcrypt hashing, never in plaintext.
- AC: JWT-protected endpoints use `require_roles(...)` dependency.
