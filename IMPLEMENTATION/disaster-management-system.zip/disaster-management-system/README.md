# Intelligent Disaster Early Warning and Evacuation Management System

A full-stack, containerized, AI/ML + GIS-enabled disaster early-warning and
evacuation coordination platform, built as a small-but-working reference
implementation for the assignment of the same name.

> **Scope note:** This is a compact, single-sprint-buildable implementation
> that demonstrates the full architecture end-to-end (real sensor ingestion →
> ML risk prediction → alerts → GIS map → shelters → citizen reporting →
> authority dashboard → RBAC → Docker). It is intentionally small so it is
> easy to read, run, and extend — see `docs/sprint_plan.md` for how a real
> team would grow it sprint by sprint.

## 1. What's included

| Layer | Technology | Notes |
|---|---|---|
| Frontend (Citizen App + Dashboard) | HTML/CSS/JS + Leaflet.js | Two pages: citizen-facing map/alerts/reporting app, and an authority/responder dashboard |
| Backend API | FastAPI (Python) | REST API, JWT auth, role-based access control |
| Database | PostgreSQL | Sensors, readings, risk assessments, alerts, shelters, incident reports, users |
| AI/ML | scikit-learn (RandomForest) | Per-disaster-type risk classifiers trained on domain-informed synthetic data, with a threshold-based fallback |
| GIS | Leaflet.js + OpenStreetMap | Affected-area / risk-zone circles, shelter markers, sensor markers, incident markers |
| Containerization | Docker + Docker Compose | `db`, `backend`, `frontend` services |
| Docs / Agile artifacts | `docs/` folder | Backlog, user stories, MoSCoW, sprint plan, Scrum board, use-case diagram, architecture |

## 2. Architecture

```
                        ┌───────────────────────────┐
   IoT / Weather /      │        Frontend            │
   Seismic sensors  ──▶ │  Citizen App | Dashboard   │◀── Citizens, Authorities,
   (simulated via       │  (HTML/JS + Leaflet GIS)   │    Responders, Admins
    /sensors/readings)  └─────────────┬──────────────┘
                                       │ REST (JSON) + JWT
                                       ▼
                         ┌─────────────────────────────┐
                         │      Backend API (FastAPI)   │
                         │  - Auth & RBAC                │
                         │  - Sensor ingestion            │
                         │  - AI/ML risk prediction        │
                         │  - Alerts (multi-channel)        │
                         │  - Shelters & resources            │
                         │  - Citizen incident reports          │
                         │  - Dashboard summary                   │
                         └───────┬───────────────────┬───────────┘
                                 │                    │
                                 ▼                    ▼
                    ┌─────────────────────┐   ┌───────────────────┐
                    │   PostgreSQL DB     │   │  ML models (joblib) │
                    │ (all persistent     │   │  RandomForest per    │
                    │  data)               │   │  disaster type         │
                    └─────────────────────┘   └───────────────────┘
```

Full details in `docs/architecture.md`.

## 3. Running it locally

**Prerequisites:** Docker + Docker Compose installed.

```bash
git clone <your-repo-url>
cd disaster-management-system
docker compose up --build
```

This starts:
- `db` — PostgreSQL on `localhost:5432`
- `backend` — FastAPI on `localhost:8000` (interactive docs at `http://localhost:8000/docs`)
- `frontend` — static site on `http://localhost:8080`

Seed some demo sensors/shelters/an admin user:

```bash
docker compose exec backend python -m app.seed_data
```

Then open:
- Citizen App: `http://localhost:8080/index.html`
- Authority Dashboard: `http://localhost:8080/dashboard.html`
  (login with `admin@disaster.gov` / `admin123` after seeding)

### Try the AI/ML pipeline end-to-end
1. On the dashboard, log in as admin.
2. Scroll to **"Simulate a Sensor Reading"**, pick a sensor + metric (e.g.
   `rainfall_mm`), enter a high value (e.g. `180`), and submit.
3. Watch the **Recent AI/ML Risk Assessments** table update with a predicted
   `disaster_type`, `risk_level`, and `risk_score` — and the corresponding
   risk-zone circle appear on the GIS map.
4. Issue an alert from the **"Issue New Alert"** form — it immediately shows
   up on the Citizen App's active-alerts list and map.
5. On the Citizen App, submit an incident report (e.g. blocked road) — it
   appears in the dashboard's **Citizen Incident Reports** table for
   responders to triage.

## 4. API reference

Once running, full interactive OpenAPI docs are at `http://localhost:8000/docs`.

Key endpoint groups:
- `POST /auth/register`, `POST /auth/login`, `GET /auth/me`
- `POST /sensors/`, `GET /sensors/`, `POST /sensors/{id}/readings` (ingest + auto risk-predict), `GET /sensors/{id}/readings`
- `GET /risk/`, `GET /risk/current`
- `POST /alerts/`, `GET /alerts/`, `PUT /alerts/{id}/deactivate`
- `POST /shelters/`, `GET /shelters/`, `PATCH /shelters/{id}`
- `POST /reports/`, `GET /reports/`, `PATCH /reports/{id}/status`
- `GET /dashboard/summary`

Roles: `citizen`, `authority`, `responder`, `admin` (see `docs/user_stories.md`
for who can do what).

## 5. Project / Agile documentation

See the `docs/` folder:
- [`docs/product_backlog.md`](docs/product_backlog.md) — prioritized product backlog (epics + backlog items)
- [`docs/user_stories.md`](docs/user_stories.md) — user stories per persona (citizen, authority, responder, admin)
- [`docs/moscow_prioritization.md`](docs/moscow_prioritization.md) — MoSCoW prioritization
- [`docs/sprint_plan.md`](docs/sprint_plan.md) — sprint goals across multiple sprints
- [`docs/scrum_board.md`](docs/scrum_board.md) — Scrum/Kanban board snapshot (To Do / In Progress / Review / Done)
- [`docs/use_case_diagram.md`](docs/use_case_diagram.md) — use-case diagram (Mermaid) + actor descriptions
- [`docs/architecture.md`](docs/architecture.md) — detailed architecture & data model
- [`docs/git_workflow.md`](docs/git_workflow.md) — branching/PR/code-review workflow used for this repo

## 6. Suggested GitHub workflow for this repo

1. Push this repo to GitHub as `main`.
2. For further work, create feature branches per backlog item, e.g.
   `feature/evacuation-route-optimizer`, `feature/sms-gateway-integration`.
3. Open Pull Requests into `main`, use the PR template ideas in
   `docs/git_workflow.md`, and require at least one review before merging.
4. Track backlog items on a GitHub Projects board mirroring
   `docs/scrum_board.md`.

## 7. Notes on scope / what's simplified

This is a small demonstration build, not a production system:
- Alert "channels" (SMS/email/push) are simulated/logged, not wired to a
  real gateway (e.g. Twilio/SES) — swap in real providers in `alerts.py`.
- Evacuation-route optimization is represented via GIS shelter/risk-zone
  mapping rather than a full routing engine (e.g. OSRM); `docs/architecture.md`
  describes how to extend it.
- ML models are trained on synthetic, domain-informed thresholds rather than
  historical disaster datasets — designed to be swapped for real training
  data (e.g. IMD/USGS/NOAA feeds) without changing the API contract.
- Citizen incident reports are anonymous-by-default for speed during
  emergencies; user-report linkage can be added easily via the existing
  `reporter_id` field.
